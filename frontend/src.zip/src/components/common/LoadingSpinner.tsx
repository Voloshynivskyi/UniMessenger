// frontend/src/components/common/LoadingSpinner.tsx
import { Box, CircularProgress } from "@mui/material";

interface Props {
  size?: number;
  color?:
    | "inherit"
    | "primary"
    | "secondary"
    | "success"
    | "error"
    | "info"
    | "warning";
}

export default function LoadingSpinner({
  size = 24,
  color = "primary",
}: Props) {
  return (
    <Box
      sx={{ display: "flex", alignItems: "center", justifyContent: "center" }}
    >
      <CircularProgress size={size} color={color} />
    </Box>
  );
}
