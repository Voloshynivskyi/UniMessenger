// frontend/src/components/common/ModalWrapper.tsx
