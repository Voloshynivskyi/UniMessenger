// frontend/src/pages/inbox/InboxChatsSidebar.tsx
