// frontend/src/pages/inbox/InboxAccountSection.tsx
