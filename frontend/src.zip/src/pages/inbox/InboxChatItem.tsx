// frontend/src/pages/inbox/InboxChatItem.tsx
