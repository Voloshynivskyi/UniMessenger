// frontend/src/pages/inbox/chat/MessageRow.tsx

import { Box, Typography } from "@mui/material";
import MessageBubble from "./MessageBubble";
import MediaRenderer from "./MediaRenderer";
import type { UnifiedTelegramMessage } from "../../../types/telegram.types";

interface Props {
  message: UnifiedTelegramMessage;
  isSelf: boolean;
}

export default function MessageRow({ message, isSelf }: Props) {
  const hasMedia = !!message.media && message.type !== "text";
  const hasText = !!message.text?.trim();

  const shouldUseBubble = !hasMedia || (hasMedia && hasText);

  const date = new Date(message.date);
  const timeStr = date.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <Box
      sx={{
        width: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: isSelf ? "flex-end" : "flex-start",
        px: 2,
        mt: 0.4, // ← менший відступ між повідомленнями
        mb: 0.2,
      }}
    >
      {/* MESSAGE CONTENT */}
      <Box sx={{ maxWidth: "75%" }}>
        {shouldUseBubble ? (
          <MessageBubble message={message} isSelf={isSelf} />
        ) : (
          <MediaRenderer message={message} />
        )}
      </Box>

      {/* TIME LABEL */}
      <Typography
        variant="caption"
        sx={{
          mt: 0.2,
          opacity: 0.55,
          fontSize: "11px",
          alignSelf: isSelf ? "flex-end" : "flex-start",
          mr: isSelf ? 0.5 : 0,
          ml: !isSelf ? 0.5 : 0,
        }}
      >
        {timeStr}
      </Typography>
    </Box>
  );
}
