// frontend/src/pages/inbox/chat/MediaRenderer.tsx

import { Box, Typography } from "@mui/material";
import { useState } from "react";
import type { UnifiedTelegramMessage } from "../../../types/telegram.types";
import { useRef } from "react";
import RoundVideoNote from "./RoundVideoNote";
import MediaViewerModal from "./MediaViewerModal";
import LoadingSpinner from "../../../components/common/LoadingSpinner";

interface Props {
  message: UnifiedTelegramMessage;
}

/**
 * Universal media renderer component.
 * Renders media content without message bubble wrapper.
 * Used for displaying photos, videos, audio, stickers, and other media types.
 */
export default function MediaRenderer({ message }: Props) {
  const { media, type } = message;
  const audioRef = useRef<HTMLAudioElement | null>(null);

  if (!media) return null;

  const fileUrl = `/api/telegram/media/${message.accountId}/${message.messageId}`;

  const isPhoto = type === "photo";
  const isGif = type === "animation";
  const isVideo = type === "video";
  const isAudio = type === "audio" || type === "voice";
  const isSticker = type === "sticker";
  const isVideoNote = type === "video_note" || media.isRoundVideo === true;

  // fullscreen
  const [viewerOpen, setViewerOpen] = useState(false);
  const [viewerType, setViewerType] = useState<"image" | "video" | null>(null);

  // loading
  const [isLoading, setIsLoading] = useState(true);

  const openViewer = (kind: "image" | "video") => {
    setViewerType(kind);
    setViewerOpen(true);
  };

  const fileName = media.fileName ?? "file";
  const fileSize = media.size;
  const duration = media.duration;

  const formatBytes = (bytes?: number) => {
    if (!bytes) return "";
    const units = ["B", "KB", "MB", "GB"];
    let i = 0;
    let v = bytes;
    while (v > 1024 && i < units.length - 1) {
      v /= 1024;
      i++;
    }
    return `${v.toFixed(1)} ${units[i]}`;
  };

  const formatDuration = (s?: number) => {
    if (!s) return "";
    const m = Math.floor(s / 60);
    const ss = String(Math.floor(s % 60)).padStart(2, "0");
    return `${m}:${ss}`;
  };

  // Media card container (not a message bubble)
  const Card: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <Box
      sx={{
        borderRadius: 3,
        overflow: "hidden",
        bgcolor: "background.paper",
        border: (theme) =>
          theme.palette.mode === "dark"
            ? `1px solid ${theme.palette.divider}`
            : `1px solid rgba(0,0,0,0.06)`,
        boxShadow: 1,
        maxWidth: 360,
        minWidth: 180,
        position: "relative",
      }}
    >
      {children}
    </Box>
  );

  // Video note (round video) without card wrapper
  if (isVideoNote) {
    return (
      <>
        <RoundVideoNote src={fileUrl} />

        {/* Caption if present */}
        {message.text && (
          <Typography
            variant="body2"
            sx={{
              mt: 1,
              whiteSpace: "pre-wrap",
              wordBreak: "break-word",
              px: 0.5,
            }}
          >
            {message.text}
          </Typography>
        )}

        <MediaViewerModal
          open={viewerOpen}
          type={viewerType}
          src={fileUrl}
          onClose={() => setViewerOpen(false)}
        />
      </>
    );
  }

  // Sticker
  if (isSticker) {
    return (
      <>
        <Box
          sx={{
            maxWidth: 200,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            p: 1,
          }}
        >
          <Box
            component="img"
            src={fileUrl}
            sx={{
              width: "100%",
              height: "auto",
              objectFit: "contain",
              display: "block",
            }}
          />
        </Box>

        {message.text && (
          <Typography
            variant="body2"
            sx={{ mt: 0.75, whiteSpace: "pre-wrap", wordBreak: "break-word" }}
          >
            {message.text}
          </Typography>
        )}
      </>
    );
  }

  // Photo
  if (isPhoto) {
    return (
      <>
        <Card>
          {isLoading && (
            <Box
              sx={{
                position: "absolute",
                inset: 0,
                bgcolor: "rgba(0,0,0,0.07)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <LoadingSpinner size={32} />
            </Box>
          )}

          <Box
            component="img"
            src={fileUrl}
            onLoad={() => setIsLoading(false)}
            onError={() => setIsLoading(false)}
            onClick={() => openViewer("image")}
            sx={{
              cursor: "pointer",
              width: "100%",
              height: "auto",
              maxHeight: 420,
              objectFit: "cover",
              opacity: isLoading ? 0 : 1,
              transition: "opacity 0.2s",
            }}
          />
        </Card>

        {message.text && (
          <Typography
            variant="body2"
            sx={{ mt: 0.75, whiteSpace: "pre-wrap", wordBreak: "break-word" }}
          >
            {message.text}
          </Typography>
        )}

        <MediaViewerModal
          open={viewerOpen}
          type={viewerType}
          src={fileUrl}
          onClose={() => setViewerOpen(false)}
        />
      </>
    );
  }

  // Video or GIF
  if (isVideo || isGif) {
    return (
      <>
        <Card>
          {isLoading && (
            <Box
              sx={{
                position: "absolute",
                inset: 0,
                bgcolor: "rgba(0,0,0,0.3)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <LoadingSpinner size={36} />
            </Box>
          )}

          <Box
            component="video"
            src={fileUrl}
            controls
            preload="metadata"
            onLoadedData={() => setIsLoading(false)}
            onClick={() => openViewer("video")}
            sx={{
              width: "100%",
              maxHeight: 420,
              bgcolor: "black",
              display: "block",
              cursor: "pointer",
              opacity: isLoading ? 0 : 1,
              transition: "opacity 0.2s",
            }}
          />
        </Card>

        {message.text && (
          <Typography
            variant="body2"
            sx={{ mt: 0.75, whiteSpace: "pre-wrap", wordBreak: "break-word" }}
          >
            {message.text}
          </Typography>
        )}

        <MediaViewerModal
          open={viewerOpen}
          type={viewerType}
          src={fileUrl}
          onClose={() => setViewerOpen(false)}
        />
      </>
    );
  }

  // ======= AUDIO / VOICE =======
  if (isAudio) {
    const [isPlaying, setIsPlaying] = useState(false);
    const audioRef = useRef<HTMLAudioElement | null>(null);

    const rawDur = duration ?? 1;

    // adaptive width of the waveform bar
    const minW = 80;
    const maxW = 220;
    const barWidth = Math.min(maxW, Math.max(minW, rawDur * 12));

    const togglePlay = () => {
      const audio = audioRef.current;
      if (!audio) return;

      if (audio.paused) {
        audio.play();
        setIsPlaying(true);
      } else {
        audio.pause();
        setIsPlaying(false);
      }
    };

    // When audio ends
    const handleEnded = () => {
      setIsPlaying(false);
    };

    return (
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 1.5,
          px: 1.5,
          py: 1,
          borderRadius: 3,
          bgcolor: "background.paper",
          border: "1px solid rgba(0,0,0,0.08)",
          boxShadow: 1,
          maxWidth: 360,
        }}
      >
        {/* PLAY / PAUSE BUTTON */}
        <Box
          sx={{
            width: 44,
            height: 44,
            borderRadius: "50%",
            bgcolor: "primary.main",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "white",
            cursor: "pointer",
            flexShrink: 0,
            transition: "0.15s",
            "&:hover": { opacity: 0.85 },
            fontSize: 22,
          }}
          onClick={togglePlay}
        >
          {isPlaying ? "⏸" : "▶"}
        </Box>

        {/* WAVEFORM BAR */}
        <Box
          sx={{
            width: barWidth,
            height: 32,
            borderRadius: 2,
            bgcolor: "rgba(0,0,0,0.08)",
            display: "flex",
            alignItems: "center",
            px: 1,
            overflow: "hidden",
          }}
        >
          <Box
            sx={{
              width: "100%",
              height: 2,
              bgcolor: "rgba(0,0,0,0.25)",
              borderRadius: 1,
            }}
          />
        </Box>

        {/* RIGHT INFO */}
        <Box sx={{ textAlign: "right", minWidth: 50 }}>
          {duration && (
            <Typography variant="caption" sx={{ opacity: 0.7 }}>
              {formatDuration(duration)}
            </Typography>
          )}
          {fileSize && (
            <Typography
              variant="caption"
              sx={{ opacity: 0.5, display: "block" }}
            >
              {formatBytes(fileSize)}
            </Typography>
          )}
        </Box>

        {/* REAL AUDIO TAG */}
        <audio
          ref={audioRef}
          src={fileUrl}
          preload="metadata"
          onEnded={handleEnded}
        />
      </Box>
    );
  }

  // File fallback for unknown types
  return (
    <Card>
      <Box sx={{ p: 1.25 }}>
        <a
          href={fileUrl}
          download={fileName}
          style={{
            display: "flex",
            alignItems: "center",
            textDecoration: "none",
            color: "inherit",
          }}
        >
          📎 {fileName}
        </a>

        {message.text && (
          <Typography
            variant="body2"
            sx={{ mt: 1, whiteSpace: "pre-wrap", wordBreak: "break-word" }}
          >
            {message.text}
          </Typography>
        )}
      </Box>
    </Card>
  );
}
