import { useEffect, useMemo, useState } from "react";
import {
  Box,
  Button,
  Divider,
  List,
  ListItemButton,
  ListItemText,
  Paper,
  TextField,
  Typography,
} from "@mui/material";

import LoginIcon from "@mui/icons-material/Login";
import RefreshIcon from "@mui/icons-material/Refresh";

import { discordApi } from "../api/discordApi";
import { socketBus } from "../realtime/eventBus";

import type { UnifiedDiscordMessage } from "../types/discord.types";
import type { DiscordNewMessagePayload } from "../realtime/events";

const DISCORD_CLIENT_ID = import.meta.env.VITE_DISCORD_CLIENT_ID;

/* ------------------------------------------------------------
 * TYPES
 * ------------------------------------------------------------ */

interface OAuthAccount {
  id: string;
  discordUserId?: string | null;
  discordUsername?: string | null;
}

interface OAuthGuild {
  id: string;
  name: string;
  owner?: boolean;
  permissions_new?: string;
}

interface DialogThread {
  chatId: string;
  name: string;
  guildId: string;
  parentId: string;
}

interface DialogChannel {
  chatId: string;
  name: string;
  guildId: string;
  discordType?: "text" | "forum" | "thread";
  threads?: DialogThread[];
}

interface DialogGuild {
  guildId: string;
  guildName: string;
  channels: DialogChannel[];
}

/* ------------------------------------------------------------
 * PAGE
 * ------------------------------------------------------------ */

export default function DiscordDebugPage() {
  /* STEP 1 — LOGIN */
  const [oauthAccount, setOauthAccount] = useState<OAuthAccount | null>(null);
  const [oauthGuilds, setOauthGuilds] = useState<OAuthGuild[]>([]);
  const [loadingOAuth, setLoadingOAuth] = useState(false);

  /* STEP 2 — LINKED GUILDS (BOT PRESENT + USER LINKED) */
  const [dialogs, setDialogs] = useState<DialogGuild[]>([]);

  /* STEP 3 — CHAT */
  const [selectedChatId, setSelectedChatId] = useState("");
  const [history, setHistory] = useState<UnifiedDiscordMessage[]>([]);
  const [messageText, setMessageText] = useState("");
  const [sending, setSending] = useState(false);

  /* ------------------------------------------------------------
   * FILTER MANAGEABLE GUILDS
   * ------------------------------------------------------------ */
  const manageableGuilds = useMemo(() => {
    return oauthGuilds.filter((g) => {
      if (g.owner) return true;
      if (g.permissions_new === "9007199254740991") return true;
      return false;
    });
  }, [oauthGuilds]);

  /* ------------------------------------------------------------
   * FLATTEN CHANNEL LIST
   * ------------------------------------------------------------ */
  const flatChannels = useMemo(() => {
    const result: any[] = [];

    for (const g of dialogs) {
      for (const ch of g.channels) {
        result.push({
          ...ch,
          guildName: g.guildName,
          isThread: false,
        });

        if (ch.threads) {
          ch.threads.forEach((t) =>
            result.push({
              ...t,
              guildName: g.guildName,
              isThread: true,
              discordType: "thread",
            })
          );
        }
      }
    }

    return result;
  }, [dialogs]);

  /* ------------------------------------------------------------
   * OAUTH FLOW
   * ------------------------------------------------------------ */

  async function startOAuth() {
    setLoadingOAuth(true);

    const { url } = await discordApi.getOAuthUrl();
    const win = window.open(url, "_blank", "width=500,height=700");

    const listener = (ev: MessageEvent) => {
      if (ev.data?.type === "DISCORD_OAUTH_SUCCESS") {
        window.removeEventListener("message", listener);
        win?.close();
        loadOAuthState();
      }
    };

    window.addEventListener("message", listener);
    setLoadingOAuth(false);
  }

  async function loadOAuthState() {
    try {
      const { account } = await discordApi.getOAuthAccount();
      setOauthAccount(account || null);

      if (!account) {
        setOauthGuilds([]);
        return;
      }

      const { guilds } = await discordApi.getOAuthGuilds(account.id);
      setOauthGuilds(guilds);
    } catch {
      setOauthAccount(null);
      setOauthGuilds([]);
    }
  }

  /* ------------------------------------------------------------
   * LINK GUILD (BOT + USER CONNECTION)
   * ------------------------------------------------------------ */

  async function linkGuild(guildId: string) {
    if (!oauthAccount) {
      alert("Login first.");
      return;
    }

    try {
      await discordApi.linkGuild(oauthAccount.id, guildId);
      alert("Guild linked!");
      await loadDialogs(); // тепер цей сервер зʼявиться у списку каналів
    } catch (e: any) {
      alert(e.message || "Error linking guild");
    }
  }

  function inviteBot(guildId: string) {
    const permissions = "268445696";
    const url = `https://discord.com/oauth2/authorize?client_id=${DISCORD_CLIENT_ID}&scope=bot&guild_id=${guildId}&permissions=${permissions}`;
    window.open(url, "_blank");
  }

  /* ------------------------------------------------------------
   * LOAD ONLY LINKED BOT DIALOGS
   * ------------------------------------------------------------ */
  async function loadDialogs() {
    const { dialogs } = await discordApi.getDialogs();
    setDialogs(dialogs);
  }

  /* ------------------------------------------------------------
   * HISTORY
   * ------------------------------------------------------------ */

  async function loadHistory(chatId?: string) {
    const id = chatId ?? selectedChatId;
    if (!id) return;

    const { messages } = await discordApi.getHistory(id);
    setHistory(messages.slice().reverse());
  }

  async function sendText() {
    if (!selectedChatId || !messageText.trim()) return;

    setSending(true);

    try {
      const { message } = await discordApi.sendText(
        selectedChatId,
        messageText
      );
      setHistory((prev) => [...prev, message]);
      setMessageText("");
    } finally {
      setSending(false);
    }
  }

  /* ------------------------------------------------------------
   * SOCKET.IO LIVE
   * ------------------------------------------------------------ */
  useEffect(() => {
    const handler = (d: DiscordNewMessagePayload) => {
      if (d.message.chatId === selectedChatId) {
        setHistory((prev) => [...prev, d.message]);
      }
    };

    socketBus.on("discord:new_message", handler);
    return () => socketBus.off("discord:new_message", handler);
  }, [selectedChatId]);

  /* ------------------------------------------------------------
   * INIT
   * ------------------------------------------------------------ */
  useEffect(() => {
    loadOAuthState();
    loadDialogs(); // поверне тільки linked guilds
  }, []);

  /* ------------------------------------------------------------
   * UI
   * ------------------------------------------------------------ */
  return (
    <Box height="90vh" display="flex" gap={2} p={2}>
      {/* STEP 1 — LOGIN + MANAGEABLE GUILDS */}
      <Paper sx={{ width: 320, p: 2, overflow: "auto" }}>
        <Typography variant="h6">Step 1 — Login</Typography>

        {!oauthAccount ? (
          <Button
            variant="contained"
            startIcon={<LoginIcon />}
            sx={{ mt: 2 }}
            onClick={startOAuth}
            disabled={loadingOAuth}
          >
            Login with Discord
          </Button>
        ) : (
          <>
            <Typography sx={{ mt: 1 }}>
              Logged in as: <b>{oauthAccount.discordUsername}</b>
            </Typography>

            <Divider sx={{ my: 2 }} />

            <Typography variant="subtitle2">Your servers</Typography>

            {manageableGuilds.map((g) => (
              <Box key={g.id} sx={{ mt: 1 }}>
                <Typography>{g.name}</Typography>

                <Button sx={{ mt: 0.5 }} onClick={() => inviteBot(g.id)}>
                  ➕ Invite bot
                </Button>

                <Button sx={{ mt: 0.5, ml: 1 }} onClick={() => linkGuild(g.id)}>
                  🔗 Link Guild
                </Button>
              </Box>
            ))}

            {manageableGuilds.length === 0 && (
              <Typography sx={{ mt: 2 }} color="text.secondary">
                No manageable servers.
              </Typography>
            )}
          </>
        )}
      </Paper>

      {/* STEP 2 — LINKED GUILDS (BOT DIALOGS) */}
      <Paper sx={{ width: 320, p: 2, overflow: "auto" }}>
        <Typography variant="h6">Step 2 — Linked Servers</Typography>

        <Typography variant="caption" color="text.secondary">
          These servers are linked to your UniMessenger account.
        </Typography>

        <Divider sx={{ my: 1.5 }} />

        <Button startIcon={<RefreshIcon />} onClick={loadDialogs}>
          Refresh
        </Button>

        <Divider sx={{ my: 1.5 }} />

        <List dense sx={{ maxHeight: 450, overflow: "auto" }}>
          {flatChannels.map((ch) => (
            <ListItemButton
              key={ch.chatId}
              selected={selectedChatId === ch.chatId}
              onClick={() => {
                setSelectedChatId(ch.chatId);
                setHistory([]);
                loadHistory(ch.chatId);
              }}
            >
              <ListItemText
                primary={ch.isThread ? `# ${ch.name} (thread)` : `# ${ch.name}`}
                secondary={ch.guildName}
              />
            </ListItemButton>
          ))}

          {flatChannels.length === 0 && (
            <Typography sx={{ mt: 1 }} color="text.secondary">
              No linked guilds. Link your servers in Step 1.
            </Typography>
          )}
        </List>
      </Paper>

      {/* STEP 3 — CHAT */}
      <Paper sx={{ flex: 1, p: 2, display: "flex", flexDirection: "column" }}>
        <Typography variant="h6">Step 3 — Chat</Typography>

        <Box flex={1} overflow="auto" mt={1}>
          {history.map((m) => (
            <Box
              key={m.messageId}
              sx={{
                mb: 1,
                bgcolor: m.isOutgoing ? "primary.main" : "grey.900",
                color: "white",
                p: 1,
                borderRadius: 1,
                maxWidth: "80%",
                alignSelf: m.isOutgoing ? "flex-end" : "flex-start",
              }}
            >
              <Typography variant="caption" sx={{ opacity: 0.7 }}>
                <b>{m.from.name}</b>
              </Typography>
              <Typography variant="body2">{m.text}</Typography>
            </Box>
          ))}

          {history.length === 0 && selectedChatId && (
            <Typography color="text.secondary">
              No messages yet. Send something.
            </Typography>
          )}

          {!selectedChatId && (
            <Typography color="text.secondary">
              Select a channel from Step 2
            </Typography>
          )}
        </Box>

        <Divider sx={{ my: 1 }} />

        <TextField
          size="small"
          fullWidth
          placeholder="Type a message..."
          disabled={!selectedChatId}
          value={messageText}
          onChange={(e) => setMessageText(e.target.value)}
        />

        <Button
          sx={{ mt: 1 }}
          variant="contained"
          disabled={!selectedChatId || sending}
          onClick={sendText}
        >
          Send
        </Button>
      </Paper>
    </Box>
  );
}
