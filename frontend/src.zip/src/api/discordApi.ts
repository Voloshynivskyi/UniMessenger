// frontend/src/api/discordApi.ts
import apiClient from "./apiClient";
import { handleApiResponse } from "./handleApiResponse";
import type { UnifiedDiscordMessage } from "../types/discord.types";

export const discordApi = {
  /* ---------------------- OAUTH ---------------------- */
  async getOAuthUrl() {
    const res = await apiClient.get("/api/discord/oauth/url");
    return handleApiResponse<{ url: string }>(res);
  },

  async getOAuthAccount() {
    const res = await apiClient.get("/api/discord/oauth/account");
    return handleApiResponse<{ account: any | null }>(res);
  },

  async getOAuthGuilds(accountId: string) {
    const res = await apiClient.get("/api/discord/oauth/guilds", {
      params: { accountId },
    });
    return handleApiResponse<{ guilds: any[] }>(res);
  },

  /* ---------------------- BOT DATA ----------------------- */
  async getDialogs() {
    const res = await apiClient.get("/api/discord/dialogs");
    return handleApiResponse<{ dialogs: any[] }>(res);
  },

  async getHistory(chatId: string) {
    const res = await apiClient.get("/api/discord/history", {
      params: { chatId },
    });
    return handleApiResponse<{ messages: UnifiedDiscordMessage[] }>(res);
  },

  async sendText(chatId: string, text: string) {
    const res = await apiClient.post("/api/discord/sendMessage", {
      chatId,
      text,
    });
    return handleApiResponse<{ message: UnifiedDiscordMessage }>(res);
  },

  async sendFile(chatId: string, file: File, caption?: string) {
    const form = new FormData();
    form.append("chatId", chatId);
    if (caption) form.append("caption", caption);
    form.append("file", file);

    const res = await apiClient.post("/api/discord/sendFile", form);
    return handleApiResponse<{ message: UnifiedDiscordMessage }>(res);
  },
  async linkGuild(discordAccountId: string, guildId: string) {
    const res = await apiClient.post("/api/discord/link-guild", {
      discordAccountId,
      guildId,
    });
    return handleApiResponse<{ linked: boolean }>(res);
  },
};
