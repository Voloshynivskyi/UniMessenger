// frontend/src/api/discordApi.ts

import apiClient from "./apiClient";
import { handleApiResponse } from "./handleApiResponse";
import type { UnifiedDiscordMessage } from "../types/discord.types";

/**
 * Один Discord-акаунт (бот) у твоїй системі.
 * Відповідає моделі backend/prisma/schema.prisma::DiscordAccount
 */
export interface DiscordAccount {
  id: string;
  userId: string;

  botToken: string; // ⚠ фактично зараз бек це теж віддає
  botUserId: string | null;
  botUsername: string | null;

  isActive: boolean;
  createdAt: string; // ISO-датка
  updatedAt: string; // ISO-датка
}

/**
 * Канал/тред, який повертає /discord/dialogs
 */
export interface DiscordDialogChannel {
  id: string;
  name: string;
  type: "text" | "announcement" | "forum" | "thread";
  parentId: string | null;
}

/**
 * Один guild з його каналами
 */
export interface DiscordDialogGuild {
  guildId: string;
  guildName: string;
  channels: DiscordDialogChannel[];
}

export const discordApi = {
  /* ---------------------------------------------
   * Додати акаунт (бот токен)
   * POST /api/discord/addAccount
   * --------------------------------------------- */
  async addAccount(botToken: string): Promise<DiscordAccount> {
    const response = await apiClient.post("/api/discord/addAccount", {
      botToken,
    });
    const data = handleApiResponse<{ account: DiscordAccount }>(response);
    return data.account;
  },

  /* ---------------------------------------------
   * Видалити/деактивувати акаунт
   * POST /api/discord/removeAccount
   * --------------------------------------------- */
  async removeAccount(accountId: string) {
    const response = await apiClient.post("/api/discord/removeAccount", {
      accountId,
    });
    // бек повертає { status:"ok", data:{ status:"ok" } }
    return handleApiResponse<{ status: string }>(response);
  },

  /* ---------------------------------------------
   * Список акаунтів поточного user'а
   * GET /api/discord/accounts
   * --------------------------------------------- */
  async getAccounts(): Promise<DiscordAccount[]> {
    const response = await apiClient.get("/api/discord/accounts");
    const data = handleApiResponse<{ accounts: DiscordAccount[] }>(response);
    return data.accounts;
  },

  /* ---------------------------------------------
   * Список guilds + каналів
   * GET /api/discord/dialogs?accountId=...
   * --------------------------------------------- */
  async getDialogs(accountId: string): Promise<DiscordDialogGuild[]> {
    const response = await apiClient.get("/api/discord/dialogs", {
      params: { accountId },
    });
    const data = handleApiResponse<{ dialogs: DiscordDialogGuild[] }>(response);
    return data.dialogs;
  },

  /* ---------------------------------------------
   * Історія каналів
   * GET /api/discord/history
   * --------------------------------------------- */
  async getHistory(params: {
    accountId: string;
    channelId: string;
    limit?: number;
  }): Promise<UnifiedDiscordMessage[]> {
    const { accountId, channelId, limit = 50 } = params;

    const response = await apiClient.get("/api/discord/history", {
      params: { accountId, channelId, limit },
    });

    const data = handleApiResponse<{ messages: UnifiedDiscordMessage[] }>(
      response
    );
    return data.messages;
  },

  /* ---------------------------------------------
   * Надіслати текст
   * POST /api/discord/sendMessage
   * --------------------------------------------- */
  async sendText(params: {
    accountId: string;
    channelId: string;
    text: string;
  }): Promise<UnifiedDiscordMessage> {
    const response = await apiClient.post("/api/discord/sendMessage", params);
    const data = handleApiResponse<{ message: UnifiedDiscordMessage }>(
      response
    );
    return data.message;
  },

  /* ---------------------------------------------
   * Надіслати файл
   * POST /api/discord/sendFile (multipart)
   * --------------------------------------------- */
  async sendFile(params: {
    accountId: string;
    channelId: string;
    file: File;
    caption?: string;
  }): Promise<UnifiedDiscordMessage> {
    const form = new FormData();
    form.append("accountId", params.accountId);
    form.append("channelId", params.channelId);
    if (params.caption) form.append("caption", params.caption);
    form.append("file", params.file);

    const response = await apiClient.post("/api/discord/sendFile", form, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    const data = handleApiResponse<{ message: UnifiedDiscordMessage }>(
      response
    );
    return data.message;
  },
};
