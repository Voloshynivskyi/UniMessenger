import React, { useState } from "react";
import AccountMenu from "../components/accounts/AccountsMenu";
import PageContainer from "../components/common/PageContainer";
const AccountsPage: React.FC = () => {
  return (
    <PageContainer>
      <AccountMenu />
    </PageContainer>
  );
};

export default AccountsPage;
