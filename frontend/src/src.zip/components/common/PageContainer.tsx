/**
 * Common page container with title and consistent paddings.
 */
import React from "react";
import { Box, Typography, Paper } from "@mui/material";

type Props = {
  children: React.ReactNode;
};

const PageContainer: React.FC<Props> = ({ children }) => {
  return (
    <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
      <Paper variant="outlined" sx={{ p: 2 }}>
        {children}
      </Paper>
    </Box>
  );
};

export default PageContainer;
