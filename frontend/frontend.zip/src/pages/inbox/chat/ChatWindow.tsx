// frontend/src/pages/inbox/chat/ChatWindow.tsx

import { useEffect, useMemo, useRef } from "react";
import { Box, Typography, Avatar, CircularProgress } from "@mui/material";
import { useUnifiedDialogs } from "../../../context/UnifiedDialogsContext";
import { useMessages } from "../../../context/UnifiedMessagesContext";
import MessageList from "./MessageList";
import MessageInput from "./MessageInput";
import { parseChatKey } from "../utils/chatUtils";

export default function ChatWindow() {
  const { selectedChatKey, chatsByAccount } = useUnifiedDialogs();
  const {
    messagesByChat,
    fetchMessages,
    loadingByChat,
    fetchedByChat,
    clearChatState,
  } = useMessages();

  const prevChatKeyRef = useRef<string | null>(null);

  // знайти обʼєкт чату за selectedChatKey
  const chat = useMemo(() => {
    if (!selectedChatKey) return null;
    const { accountId } = parseChatKey(selectedChatKey);
    const byAccount = (chatsByAccount as any)[accountId] || {};
    return byAccount[selectedChatKey] || null;
  }, [selectedChatKey, chatsByAccount]);

  const messages = selectedChatKey ? messagesByChat[selectedChatKey] ?? [] : [];

  const isChatLoading = selectedChatKey
    ? !!loadingByChat[selectedChatKey]
    : false;

  // при зміні чату — обрізаємо попередній до останніх 50
  useEffect(() => {
    const prevKey = prevChatKeyRef.current;
    if (prevKey && prevKey !== selectedChatKey) {
      clearChatState(prevKey);
    }
    prevChatKeyRef.current = selectedChatKey ?? null;
  }, [selectedChatKey, clearChatState]);

  // початковий фетч повідомлень для нового чату
  useEffect(() => {
    if (!selectedChatKey || !chat) return;

    if (fetchedByChat[selectedChatKey]) {
      // вже колись фетчили – показуємо те, що є в памʼяті
      return;
    }

    if (!chat.peerType || !chat.chatId) return;

    fetchMessages({
      chatKey: selectedChatKey,
      accountId: chat.accountId,
      peerType: chat.peerType,
      peerId: chat.chatId,
      accessHash: chat.accessHash,
    });
  }, [selectedChatKey, chat, fetchedByChat, fetchMessages]);

  // якщо чат не обраний
  if (!selectedChatKey) {
    return (
      <Box
        sx={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "text.secondary",
        }}
      >
        <Typography variant="body1">
          Select a chat to start messaging
        </Typography>
      </Box>
    );
  }

  // якщо чатKey є, але самого чату немає в словнику (наприклад, ще не завантажили діалоги)
  if (!chat) {
    return (
      <Box
        sx={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "text.secondary",
        }}
      >
        <Typography variant="body1">
          Chat is not available. Try refreshing dialogs.
        </Typography>
      </Box>
    );
  }

  const title = chat.displayName || chat.title || "Chat";
  const subtitle =
    chat.platform === "telegram" ? "Telegram" : chat.platform ?? "";

  return (
    <Box
      sx={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        borderLeft: (theme) => `1px solid ${theme.palette.divider}`,
      }}
    >
      {/* HEADER */}
      <Box
        sx={{
          px: 2,
          py: 1.5,
          display: "flex",
          alignItems: "center",
          borderBottom: (theme) => `1px solid ${theme.palette.divider}`,
          gap: 1.5,
        }}
      >
        <Avatar
          sx={{ width: 40, height: 40, bgcolor: "primary.main" }}
          src={chat.photoUrl || undefined}
        >
          {title?.[0]?.toUpperCase?.()}
        </Avatar>
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Typography variant="subtitle1" noWrap sx={{ fontWeight: 600 }}>
            {title}
          </Typography>
          <Typography variant="caption" color="text.secondary" noWrap>
            {subtitle}
          </Typography>
        </Box>
      </Box>

      {/* BODY: messages + input */}
      <Box
        sx={{
          flex: 1,
          minHeight: 0,
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* Показуємо loader поверх MessageList тільки на первинний фетч */}
        <Box
          sx={{
            position: "relative",
            flex: 1,
            minHeight: 0,
            display: "flex",
            flexDirection: "column",
          }}
        >
          <MessageList
            chatKey={selectedChatKey}
            chat={{
              accountId: chat.accountId,
              peerType: chat.peerType,
              chatId: chat.chatId,
              accessHash: chat.accessHash,
            }}
            messages={messages}
          />

          {isChatLoading && !fetchedByChat[selectedChatKey] && (
            <Box
              sx={{
                position: "absolute",
                inset: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                bgcolor: "background.default",
                opacity: 0.85,
              }}
            >
              <CircularProgress />
            </Box>
          )}
        </Box>

        {/* INPUT внизу */}
        <Box
          sx={{
            px: 1.5,
            py: 1,
            borderTop: (theme) => `1px solid ${theme.palette.divider}`,
          }}
        >
          <MessageInput
            chatKey={selectedChatKey}
            accountId={chat.accountId}
            peerType={chat.peerType}
            peerId={chat.chatId}
            accessHash={chat.accessHash}
          />
        </Box>
      </Box>
    </Box>
  );
}
