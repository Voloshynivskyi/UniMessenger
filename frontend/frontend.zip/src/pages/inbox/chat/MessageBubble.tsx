// frontend/src/pages/inbox/chat/MessageBubble.tsx

import { Box, Typography } from "@mui/material";
import type { UnifiedTelegramMessage } from "../../../types/telegram.types";

interface Props {
  message: UnifiedTelegramMessage;
  isSelf: boolean;
}

export default function MessageBubble({ message, isSelf }: Props) {
  const date = new Date(message.date);

  const bubbleBg = isSelf ? "primary.main" : "background.paper";
  const bubbleColor = isSelf ? "primary.contrastText" : "text.primary";

  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: isSelf ? "flex-end" : "flex-start",
      }}
    >
      <Box
        sx={{
          maxWidth: "65%",
          px: 1.75,
          py: 1,
          borderRadius: 2,
          bgcolor: bubbleBg,
          color: bubbleColor,
          boxShadow: 1,
          position: "relative",
          pr: 6, // extra right padding for time
        }}
      >
        {/* TEXT */}
        {message.type === "text" && (
          <Typography
            variant="body2"
            sx={{
              whiteSpace: "pre-wrap",
              wordBreak: "break-word",
            }}
          >
            {message.text}
          </Typography>
        )}

        {/* PHOTO */}
        {message.type === "photo" && message.media?.photo && (
          <Box>
            <Box
              component="img"
              src={`/api/telegram/photo/${message.media.photo.id}`}
              alt="photo"
              sx={{
                display: "block",
                maxWidth: "100%",
                borderRadius: 1.5,
              }}
            />
            {message.text && (
              <Typography
                variant="body2"
                sx={{
                  mt: 0.5,
                  whiteSpace: "pre-wrap",
                  wordBreak: "break-word",
                }}
              >
                {message.text}
              </Typography>
            )}
          </Box>
        )}

        {/* TIME */}
        <Typography
          variant="caption"
          sx={{
            position: "absolute",
            bottom: 2,
            right: 8,
            opacity: 0.7,
            fontSize: 10,
          }}
        >
          {date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </Typography>
      </Box>
    </Box>
  );
}
