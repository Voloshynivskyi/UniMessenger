import { Router } from "express";
import multer from "multer";
import { requireAuth } from "../middleware/requireAuth";

import {
  discordGetOAuthUrl,
  discordOAuthCallback,
  discordGetOAuthAccount,
  discordGetOAuthGuilds,
  discordGetDialogs,
  discordGetHistory,
  discordSendMessage,
  discordSendFile,
  discordLinkGuild,
} from "../controllers/discordController";

const upload = multer({ storage: multer.memoryStorage() });
const router = Router();

/* ---------------------- OAUTH ---------------------- */
router.get("/oauth/url", requireAuth, discordGetOAuthUrl);
router.get("/oauth/callback", discordOAuthCallback);
router.get("/oauth/account", requireAuth, discordGetOAuthAccount);
router.get("/oauth/guilds", requireAuth, discordGetOAuthGuilds);

router.post("/link-guild", requireAuth, discordLinkGuild);

/* ---------------------- BOT (GLOBAL) ---------------------- */
router.get("/dialogs", requireAuth, discordGetDialogs);
router.get("/history", requireAuth, discordGetHistory);
router.post("/sendMessage", requireAuth, discordSendMessage);
router.post("/sendFile", requireAuth, upload.single("file"), discordSendFile);

export default router;
