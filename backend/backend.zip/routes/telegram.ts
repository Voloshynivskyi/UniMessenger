/**
 * backend/routes/telegram.ts
 * Routes for Telegram MTProto authentication and account management
 */

import { Router } from "express";
import {
  sendCode,
  signIn,
  logout,
  verifyTwoFA,
  getTelegramAccounts,
  getDialogs,
  getMessageHistory,
  sendMessage,
} from "../controllers/telegramController";
import { requireAuth } from "../middleware/requireAuth";
import { getTelegramMedia } from "../controllers/mediaController";
import { getTelegramAvatar } from "../controllers/mediaController";

import multer from "multer";

const router = Router();

/**
 * @route POST /telegram/sendCode
 * @desc Send Telegram authentication code via MTProto
 * @access Private
 */
router.post("/sendCode", requireAuth, sendCode);

/**
 * @route POST /telegram/signIn
 * @desc Complete MTProto sign-in (code-based)
 * @access Private
 */
router.post("/signIn", requireAuth, signIn);

/**
 * @route POST /telegram/2fa
 * @desc Complete MTProto 2FA password step
 * @access Private
 */
router.post("/2fa", requireAuth, verifyTwoFA);

/**
 * @route POST /telegram/logout
 * @desc Logout Telegram account (invalidate session)
 * @access Private
 */
router.post("/logout", requireAuth, logout);

/**
 * @route GET /telegram/accounts
 * @desc Get all Telegram accounts attached to current user
 * @access Private
 */
router.get("/accounts", requireAuth, getTelegramAccounts);

/**
 * @route GET /telegram/dialogs
 * @desc Get dialogs for a specific Telegram account
 * @access Private
 */
router.get("/dialogs", requireAuth, getDialogs);

/**
 * @route GET /telegram/history
 * @desc Get message history for a specific Telegram account
 * @access Private
 */
router.get("/history", requireAuth, getMessageHistory);

/** * @route GET /media/telegram/:accountId/:fileId
 * @desc Stream Telegram media files (photos, videos, documents, etc.)
 * @access Private
 */
router.get("/media/:accountId/:fileId", requireAuth, getTelegramMedia);

// Multer setup for handling file uploads in sendMessage
const upload = multer({ storage: multer.memoryStorage() });

/**
 * @route POST /telegram/sendMessage
 * @desc Send a message (with optional media) via Telegram MTProto
 * @access Private
 */
router.post("/sendMessage", requireAuth, upload.single("file"), sendMessage);

/** * @route GET /media/telegram/avatar/:accountId/:photoId
 * @desc Stream Telegram user/channel/chat avatar photos
 * @access Private
 */
router.get("/avatar/:accountId/:photoId", requireAuth, getTelegramAvatar);

export default router;
