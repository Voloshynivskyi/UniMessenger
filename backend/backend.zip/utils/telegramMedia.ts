// backend/utils/telegramMedia.ts

import { Api } from "telegram";
import { appendLog } from "./debugLogger";

/**
 * Realtime media type used in websocket payloads.
 * Defines the type of media contained in a Telegram message.
 */
export type TelegramRealtimeMessageType =
  | "text"
  | "photo"
  | "video"
  | "animation"
  | "voice"
  | "audio"
  | "video_note"
  | "file"
  | "sticker"
  | "service"
  | "webpage"
  | "unknown";

export interface TelegramRealtimeMedia {
  fileId: string;
  mimeType?: string | undefined;
  fileName?: string | undefined;
  fileSize?: number | undefined;
  width?: number | undefined;
  height?: number | undefined;
  duration?: number | undefined;
  isSticker?: boolean | undefined;
  isAnimated?: boolean | undefined;
  isRoundVideo?: boolean | undefined;
  previewUrl?: string | undefined;
  title?: string | undefined;
  description?: string | undefined;
  siteName?: string | undefined;
  displayUrl?: string | undefined;
  photo?:
    | {
        fileId: string;
        width?: number;
        height?: number;
      }
    | null
    | undefined;
}

/**
 * Main MTProto Api.Message media extractor function.
 */
export function extractMediaFromMessage(msg: Api.Message): {
  type: TelegramRealtimeMessageType;
  media: TelegramRealtimeMedia | null;
  mediaGroupId: string | null;
} {
  const rawMedia = msg.media;
  const mediaGroupId =
    (msg as any).groupedId != null ? String((msg as any).groupedId) : null;

  // Logging raw media object
  appendLog("MEDIA_RAW_INPUT", {
    msgId: msg.id,
    className: rawMedia?.constructor?.name,
    groupedId: mediaGroupId,
    raw: rawMedia,
  });

  if (!rawMedia) {
    appendLog("MEDIA_NONE", { msgId: msg.id });
    return { type: "text", media: null, mediaGroupId };
  }

  // ───────────────────────────────────────────────
  // PHOTO
  // ───────────────────────────────────────────────
  if (
    rawMedia instanceof Api.MessageMediaPhoto &&
    rawMedia.photo instanceof Api.Photo
  ) {
    const photo = rawMedia.photo as Api.Photo;
    const best = selectBestPhotoSize(photo.sizes);

    const media: TelegramRealtimeMedia = {
      fileId: String(photo.id),
      mimeType: "image/jpeg",
      fileSize:
        typeof (photo as any).size === "number"
          ? (photo as any).size
          : undefined,
      width: best.w,
      height: best.h,
    };

    appendLog("MEDIA_PHOTO_PARSED", {
      msgId: msg.id,
      fileId: media.fileId,
      width: media.width,
      height: media.height,
      size: media.fileSize,
      groupedId: mediaGroupId,
    });

    return { type: "photo", media, mediaGroupId };
  }

  // ───────────────────────────────────────────────
  // DOCUMENT-BASED (video, audio, voice, sticker, gif, file, etc.)
  // ───────────────────────────────────────────────
  if (
    rawMedia instanceof Api.MessageMediaDocument &&
    rawMedia.document instanceof Api.Document
  ) {
    const doc = rawMedia.document as Api.Document;
    const mimeType = doc.mimeType ?? "application/octet-stream";

    appendLog("MEDIA_DOCUMENT_ATTRIBUTES", {
      msgId: msg.id,
      documentId: doc.id,
      mimeType,
      attributes: doc.attributes,
    });

    const {
      type,
      fileName,
      width,
      height,
      duration,
      isSticker,
      isAnimated,
      isRoundVideo,
    } = parseDocumentKindAndAttributes(mimeType, doc.attributes || []);

    const media: TelegramRealtimeMedia = {
      fileId: String(doc.id),
      mimeType,
      fileName,
      fileSize:
        typeof doc.size === "number" ? doc.size : Number(doc.size) || undefined,
      width,
      height,
      duration,
      isSticker,
      isAnimated,
      isRoundVideo,
    };

    appendLog("MEDIA_DOCUMENT_PARSED", {
      msgId: msg.id,
      type,
      fileId: media.fileId,
      mimeType: media.mimeType,
      fileName: media.fileName,
      width: media.width,
      height: media.height,
      duration: media.duration,
      isSticker,
      isAnimated,
      isRoundVideo,
      groupedId: mediaGroupId,
    });

    return { type, media, mediaGroupId };
  }

  // ───────────────────────────────────────────────
  // WEB PAGE PREVIEW (поки мінімальна підтримка)
  // ───────────────────────────────────────────────
  if (
    rawMedia instanceof Api.MessageMediaWebPage &&
    rawMedia.webpage instanceof Api.WebPage
  ) {
    const page = rawMedia.webpage as Api.WebPage;

    const media: TelegramRealtimeMedia = {
      fileId: `webpage:${String(page.id)}`,
      mimeType: "text/html",
      fileName: (page as any).siteName || undefined,
    };

    appendLog("MEDIA_WEBPAGE_PARSED", {
      msgId: msg.id,
      fileId: media.fileId,
      siteName: media.fileName,
      groupedId: mediaGroupId,
    });

    if (
      rawMedia instanceof Api.MessageMediaWebPage &&
      rawMedia.webpage instanceof Api.WebPage
    ) {
      const page = rawMedia.webpage as Api.WebPage;

      const media = parseWebPageMedia(page);

      return {
        type: "webpage",
        media,
        mediaGroupId,
      };
    }
  }

  // ───────────────────────────────────────────────
  // UNKNOWN
  // ───────────────────────────────────────────────
  appendLog("MEDIA_UNKNOWN_TYPE", {
    msgId: msg.id,
    className: rawMedia.constructor?.name,
    raw: rawMedia,
  });

  return { type: "unknown", media: null, mediaGroupId };
}

/* ========================================================================
   HELPERS
   ======================================================================== */

/**
 * Selects the best photo size from the available options.
 */
function selectBestPhotoSize(sizes: Api.TypePhotoSize[]) {
  if (!sizes || sizes.length === 0) {
    return { w: 0, h: 0 };
  }

  const progressive = sizes.find(
    (s) => s instanceof Api.PhotoSizeProgressive
  ) as Api.PhotoSizeProgressive | undefined;

  if (progressive) {
    return {
      w: progressive.w ?? 0,
      h: progressive.h ?? 0,
    };
  }

  let best: any = sizes[0];

  for (const s of sizes) {
    if ("w" in s && "h" in s) {
      if ((s.w ?? 0) * (s.h ?? 0) > (best.w ?? 0) * (best.h ?? 0)) {
        best = s;
      }
    }
  }

  return {
    w: best.w ?? 0,
    h: best.h ?? 0,
  };
}

/**
 * Parses Document.attributes to determine the type of media
 */
function parseDocumentKindAndAttributes(
  mimeType: string,
  attrs: Api.TypeDocumentAttribute[]
): {
  type: TelegramRealtimeMessageType;
  fileName?: string | undefined;
  width?: number | undefined;
  height?: number | undefined;
  duration?: number | undefined;
  isSticker: boolean;
  isAnimated: boolean;
  isRoundVideo: boolean;
} {
  let fileName: string | undefined = undefined;
  let width: number | undefined = undefined;
  let height: number | undefined = undefined;
  let duration: number | undefined = undefined;

  let isSticker = false;
  let isAnimated = false;
  let isRoundVideo = false;
  let isVoice = false;

  for (const attr of attrs) {
    if (attr instanceof Api.DocumentAttributeFilename) {
      fileName = attr.fileName;
    } else if (attr instanceof Api.DocumentAttributeVideo) {
      width = attr.w ?? width;
      height = attr.h ?? height;
      duration = attr.duration ?? duration;
      isRoundVideo = attr.roundMessage ?? isRoundVideo;
    } else if (attr instanceof Api.DocumentAttributeAudio) {
      duration = attr.duration ?? duration;
      if (attr.voice) isVoice = true;
    } else if (attr instanceof Api.DocumentAttributeSticker) {
      isSticker = true;
    } else if (attr instanceof Api.DocumentAttributeAnimated) {
      isAnimated = true;
    }
  }

  let type: TelegramRealtimeMessageType = "file";

  if (isSticker) {
    type = "sticker";
  } else if (isRoundVideo) {
    type = "video_note";
  } else if (isVoice) {
    type = "voice";
  } else if (mimeType.startsWith("video/")) {
    type = "video";
  } else if (mimeType === "image/gif" || isAnimated) {
    type = "animation";
  } else if (mimeType.startsWith("audio/")) {
    type = "audio";
  } else if (mimeType.startsWith("image/")) {
    type = "photo";
  }

  return {
    type,
    fileName,
    width,
    height,
    duration,
    isSticker,
    isAnimated,
    isRoundVideo,
  };
}

function parseWebPageMedia(page: Api.WebPage) {
  const media: TelegramRealtimeMedia = {
    fileId: `webpage:${String(page.id)}`,
    mimeType: "text/html",
    title: page.title ?? undefined,
    description: page.description ?? undefined,
    siteName: (page as any).siteName ?? undefined,
    displayUrl: page.displayUrl ?? undefined,
    previewUrl: page.url ?? undefined,
  };

  // Фото превʼю
  if (page.photo instanceof Api.Photo) {
    const best = selectBestPhotoSize(page.photo.sizes);
    media.photo = {
      fileId: String(page.photo.id),
      width: best.w,
      height: best.h,
    };

    appendLog("MEDIA_WEBPAGE_PHOTO", {
      pageId: page.id,
      photoId: media.photo.fileId,
      width: best.w,
      height: best.h,
    });
  }

  appendLog("MEDIA_WEBPAGE_PARSED_FULL", {
    pageId: page.id,
    title: media.title,
    description: media.description,
    siteName: media.siteName,
    url: media.previewUrl,
  });

  return media;
}
