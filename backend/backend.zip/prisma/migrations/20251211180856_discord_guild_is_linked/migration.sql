-- AlterTable
ALTER TABLE "DiscordGuild" ADD COLUMN     "isLinked" BOOLEAN NOT NULL DEFAULT false;
