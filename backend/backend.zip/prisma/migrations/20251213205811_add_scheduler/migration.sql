-- CreateIndex
CREATE INDEX "ScheduledPost_status_idx" ON "ScheduledPost"("status");

-- CreateIndex
CREATE INDEX "ScheduledPostTarget_platform_idx" ON "ScheduledPostTarget"("platform");
