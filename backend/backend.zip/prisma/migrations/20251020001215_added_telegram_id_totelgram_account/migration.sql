-- AlterTable
ALTER TABLE "TelegramAccount" ADD COLUMN     "telegramId" TEXT;
