-- AlterTable
ALTER TABLE "TelegramAccount" ADD COLUMN     "isActive" BOOLEAN NOT NULL DEFAULT false;
