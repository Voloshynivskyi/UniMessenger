-- CreateIndex
CREATE INDEX "DiscordBotGuild_botId_idx" ON "DiscordBotGuild"("botId");
