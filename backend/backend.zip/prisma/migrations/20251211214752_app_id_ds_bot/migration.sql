-- AlterTable
ALTER TABLE "DiscordBot" ADD COLUMN     "applicationId" TEXT;
