// backend/services/discord/discordService.ts

import { prisma } from "../../lib/prisma";
import { discordClientManager } from "./discordClientManager"; // MULTI-BOT MANAGER
import { parseDiscordMessage } from "../../utils/discord/parseDiscordMessage";
import { getSocketGateway } from "../../realtime/socketGateway";
import { logger } from "../../utils/logger";
import axios from "axios";

const DISCORD_CLIENT_ID = process.env.DISCORD_CLIENT_ID!;
const DISCORD_CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET!;
const REDIRECT_URI =
  process.env.DISCORD_OAUTH_REDIRECT ||
  "http://localhost:7007/api/discord/oauth/callback";

/* ------------------------------------------------------------
 * 1) OAUTH — авторизація користувача Discord (не бота)
 * ------------------------------------------------------------ */
export class DiscordService {
  getOAuthUrl(userId: string) {
    const state = Buffer.from(JSON.stringify({ userId })).toString("base64");

    const params = new URLSearchParams({
      client_id: DISCORD_CLIENT_ID,
      redirect_uri: REDIRECT_URI,
      response_type: "code",
      scope: "identify guilds",
      state,
      prompt: "consent",
    });

    return { url: `https://discord.com/api/oauth2/authorize?${params}` };
  }

  async handleOAuthCallback(code: string, rawState: string) {
    const { userId } = JSON.parse(
      Buffer.from(rawState, "base64").toString("utf8")
    );

    // 1. Exchange code for token
    const tokenResp = await axios.post(
      "https://discord.com/api/oauth2/token",
      new URLSearchParams({
        client_id: DISCORD_CLIENT_ID,
        client_secret: DISCORD_CLIENT_SECRET,
        grant_type: "authorization_code",
        code,
        redirect_uri: REDIRECT_URI,
      }),
      { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
    );

    const { access_token, refresh_token, expires_in } = tokenResp.data;
    const expiresAt = new Date(Date.now() + expires_in * 1000);

    // 2. Get /users/@me
    const userResp = await axios.get("https://discord.com/api/users/@me", {
      headers: { Authorization: `Bearer ${access_token}` },
    });

    const discordUser = userResp.data;

    // 3. Upsert OAuth account
    const oauth = await prisma.discordAccount.upsert({
      where: { discordUserId: discordUser.id },
      create: {
        userId,
        discordUserId: discordUser.id,
        discordUsername: discordUser.username,
        accessToken: access_token,
        refreshToken: refresh_token,
        tokenExpiresAt: expiresAt,
      },
      update: {
        userId,
        discordUsername: discordUser.username,
        accessToken: access_token,
        refreshToken: refresh_token,
        tokenExpiresAt: expiresAt,
      },
    });

    return { account: oauth };
  }

  async getOAuthAccount(userId: string) {
    return prisma.discordAccount.findFirst({
      where: { userId, isActive: true },
    });
  }

  async getOAuthGuilds(accountId: string) {
    const acc = await prisma.discordAccount.findUnique({
      where: { id: accountId },
    });

    if (!acc?.accessToken) return [];

    const resp = await axios.get("https://discord.com/api/users/@me/guilds", {
      headers: { Authorization: `Bearer ${acc.accessToken}` },
    });

    return resp.data;
  }

  /* ------------------------------------------------------------
   * 2) USER ADDS BOT (botToken)
   * ------------------------------------------------------------ */
  async registerUserBot(userId: string, botToken: string) {
    // create bot db row
    const bot = await prisma.discordBot.create({
      data: {
        userId,
        botToken,
      },
    });

    // attach discord.js client
    const client = await discordClientManager.attachBot(bot.id, botToken);

    // save bot user info
    await prisma.discordBot.update({
      where: { id: bot.id },
      data: {
        botUserId: client.user?.id ?? null,
        botUsername: client.user?.username ?? null,
      },
    });

    return bot;
  }

  /* ------------------------------------------------------------
   * 3) BOT GUILDS — обновляємо список серверів, куди бот доданий
   * ------------------------------------------------------------ */
  async refreshBotGuilds(botId: string) {
    const client = discordClientManager.getClient(botId);

    if (!client) throw new Error("Bot client not found");

    const guilds = [...client.guilds.cache.values()];

    await prisma.discordBotGuild.deleteMany({ where: { botId } });

    for (const g of guilds) {
      await prisma.discordBotGuild.create({
        data: {
          botId,
          guildId: g.id,
          name: g.name,
          icon: g.icon ?? null,
        },
      });
    }

    return guilds.length;
  }

  /* ------------------------------------------------------------
   * 4) GET DIALOGS — ONLY FOR BOTS OWNED BY USER
   * ------------------------------------------------------------ */
  async getDialogsForUser(userId: string) {
    const bots = await prisma.discordBot.findMany({
      where: { userId },
      include: { guilds: true },
    });

    const dialogs = [];

    for (const bot of bots) {
      const client = discordClientManager.getClient(bot.id);
      if (!client) continue;

      const tree = await discordClientManager.getDialogsTree(bot.id);

      dialogs.push({
        botId: bot.id,
        botUsername: bot.botUsername,
        guilds: tree,
      });
    }

    return dialogs;
  }

  /* ------------------------------------------------------------
   * 5) HISTORY
   * ------------------------------------------------------------ */
  async getHistory(botId: string, chatId: string) {
    const msgs = await discordClientManager.fetchMessages(botId, chatId);

    return msgs.map((msg) =>
      parseDiscordMessage({
        message: msg,
        botId,
        guildId: msg.guild?.id!,
        channelId: chatId,
      })
    );
  }

  /* ------------------------------------------------------------
   * 6) SEND MESSAGE
   * ------------------------------------------------------------ */
  async sendMessage(
    botId: string,
    chatId: string,
    text: string,
    userId: string
  ) {
    const sent = await discordClientManager.sendMessage(botId, chatId, text);

    const parsed = parseDiscordMessage({
      message: sent,
      botId,
      guildId: sent.guild!.id,
      channelId: chatId,
    });

    getSocketGateway().emitToUser(userId, "discord:message_confirmed", {
      platform: "discord",
      botId,
      chatId,
      message: parsed,
    });

    return parsed;
  }
}

export const discordService = new DiscordService();
