// backend/services/discord/discordService.ts
import discordClientManager from "./discordClientManager";
import { prisma } from "../../lib/prisma";
import { parseDiscordMessage } from "../../utils/discord/parseDiscordMessage";
import { getSocketGateway } from "../../realtime/socketGateway";

export class DiscordService {
  /* ---------------------------------------------
   * Attach bot
   * --------------------------------------------- */
  async addAccount(userId: string, botToken: string) {
    // ✅ 1. Перевіряємо, чи такий бот вже існує
    const existing = await prisma.discordAccount.findFirst({
      where: { botToken },
    });

    if (existing) {
      // якщо бот є — просто переконуємось, що він активний
      if (!existing.isActive) {
        await prisma.discordAccount.update({
          where: { id: existing.id },
          data: { isActive: true },
        });

        await discordClientManager.attachAccount(existing.id, botToken);
      }

      return existing;
    }

    // ✅ 2. Якщо бота ще НЕ існує — створюємо
    const account = await prisma.discordAccount.create({
      data: {
        userId,
        botToken,
        isActive: true,
      },
    });

    await discordClientManager.attachAccount(account.id, botToken);

    return account;
  }

  /* ---------------------------------------------
   * Remove bot
   * --------------------------------------------- */
  async removeAccount(accountId: string) {
    await discordClientManager.detachAccount(accountId);

    await prisma.discordAccount.update({
      where: { id: accountId },
      data: { isActive: false },
    });

    return { status: "ok" };
  }

  /* ---------------------------------------------
   * Get accounts
   * --------------------------------------------- */
  async getAccounts(userId: string) {
    return prisma.discordAccount.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
    });
  }

  /* ---------------------------------------------
   * Get dialogs (guilds + channels + threads)
   * --------------------------------------------- */
  async getDialogs(accountId: string) {
    const inst = (discordClientManager as any).clients.get(accountId);
    if (!inst) throw new Error("Discord client not active");

    const result: any[] = [];

    for (const [guildId, guildName] of inst.guilds) {
      const channels: any[] = [];

      // ✅ ТЕКСТОВІ / ANNOUNCEMENT / FORUM
      for (const ch of inst.channels.values()) {
        if ((ch as any).guildId !== guildId) continue;

        channels.push({
          id: ch.id,
          name: ch.name,
          type: ch.type,
          parentId: null,
        });
      }

      // ✅ ВСІ THREADS (і forum-posts теж)
      for (const t of inst.threads.values()) {
        if ((t as any).guildId !== guildId) continue;

        channels.push({
          id: t.id,
          name: t.name,
          type: t.type,
          parentId: t.parentId ?? null,
        });
      }

      result.push({
        guildId,
        guildName,
        channels,
      });
    }

    return result;
  }

  /* ---------------------------------------------
   * Get history
   * --------------------------------------------- */
  async getHistory(accountId: string, channelId: string, limit = 50) {
    const messages = await discordClientManager.fetchMessages(
      accountId,
      channelId,
      limit
    );

    return messages.map((msg) => parseDiscordMessage(msg, accountId));
  }

  /* ---------------------------------------------
   * Send text
   * --------------------------------------------- */
  async sendMessage(accountId: string, channelId: string, text: string) {
    const sent = await discordClientManager.sendMessage(
      accountId,
      channelId,
      text
    );

    const parsed = parseDiscordMessage(sent, accountId);

    // ✅ REALTIME CONFIRM
    const account = await prisma.discordAccount.findUnique({
      where: { id: accountId },
    });

    if (account) {
      getSocketGateway().emitToUser(
        account.userId,
        "discord:message_confirmed",
        {
          platform: "discord",
          accountId,
          timestamp: new Date().toISOString(),
          chatId: channelId,
          tempId: parsed.messageId, // тимчасово = реальний id
          message: parsed,
        }
      );
    }

    return parsed;
  }

  /* ---------------------------------------------
   * Send file
   * --------------------------------------------- */
  async sendFile(
    accountId: string,
    channelId: string,
    fileBuf: Buffer,
    fileName: string,
    caption?: string
  ) {
    const sent = await discordClientManager.sendFile(
      accountId,
      channelId,
      fileBuf,
      fileName,
      caption
    );

    const parsed = parseDiscordMessage(sent, accountId);

    // ✅ REALTIME CONFIRM
    const account = await prisma.discordAccount.findUnique({
      where: { id: accountId },
    });

    if (account) {
      getSocketGateway().emitToUser(
        account.userId,
        "discord:message_confirmed",
        {
          platform: "discord",
          accountId,
          timestamp: new Date().toISOString(),
          chatId: channelId,
          tempId: parsed.messageId,
          message: parsed,
        }
      );
    }

    return parsed;
  }
}

export const discordService = new DiscordService();
