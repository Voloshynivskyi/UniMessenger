// backend/services/discord/discordClientManager.ts

import {
  ChannelType,
  Client,
  GatewayIntentBits,
  Partials,
  TextChannel,
  NewsChannel,
  ThreadChannel,
  ForumChannel,
  Message,
  type TextBasedChannel,
  type PartialMessage,
  type Typing,
} from "discord.js";

import {
  emitDiscordNewMessage,
  emitDiscordEditedMessage,
  emitDiscordDeletedMessage,
  emitDiscordTyping,
} from "../../realtime/handlers/discord/discordUpdateHandlers";

import { logger } from "../../utils/logger";

/* ============================================================
   TYPES
============================================================ */

interface DiscordBotRuntime {
  client: Client;
  token: string;

  guilds: Map<string, string>;
  channels: Map<string, TextChannel | NewsChannel | ForumChannel>;
  threads: Map<string, ThreadChannel>;
}

/* ============================================================
   TYPE GUARDS
============================================================ */

function isForumChannel(ch: any): ch is ForumChannel {
  return ch?.type === ChannelType.GuildForum;
}

function isTextChannel(ch: any): ch is TextChannel | NewsChannel {
  return (
    ch?.type === ChannelType.GuildText ||
    ch?.type === ChannelType.GuildAnnouncement
  );
}

function isThreadChannel(ch: any): ch is ThreadChannel {
  return (
    ch?.type === ChannelType.PublicThread ||
    ch?.type === ChannelType.PrivateThread ||
    ch?.type === ChannelType.AnnouncementThread
  );
}

function isSendableChannel(
  ch: any
): ch is TextChannel | NewsChannel | ThreadChannel {
  return isTextChannel(ch) || isThreadChannel(ch);
}

/* ============================================================
   MULTI-BOT CLIENT MANAGER
============================================================ */

export class DiscordClientManager {
  // KEY = discordAccountId from Prisma
  private bots: Map<string, DiscordBotRuntime> = new Map();

  /* ------------------------------------------------------------
     ATTACH BOT INSTANCE
  ------------------------------------------------------------ */

  public async attachBot(discordAccountId: string, botToken: string) {
    if (this.bots.has(discordAccountId)) {
      logger.info(
        `[DiscordClientManager] Bot already attached for account ${discordAccountId}`
      );
      return this.bots.get(discordAccountId)!.client;
    }

    const client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMessageTyping,
      ],
      partials: [Partials.Channel, Partials.Message, Partials.User],
    });

    const runtime: DiscordBotRuntime = {
      client,
      token: botToken,
      guilds: new Map(),
      channels: new Map(),
      threads: new Map(),
    };

    this.registerEvents(discordAccountId, runtime);

    logger.info(`[DiscordClientManager] Logging in bot ${discordAccountId}...`);
    await client.login(botToken);

    logger.info(
      `[DiscordClientManager] Bot for account ${discordAccountId} logged in as ${client.user?.tag}`
    );

    await this.preloadStructures(runtime);

    this.bots.set(discordAccountId, runtime);
    return client;
  }

  /* ------------------------------------------------------------
     DETACH BOT
  ------------------------------------------------------------ */

  public async detachBot(discordAccountId: string) {
    const bot = this.bots.get(discordAccountId);
    if (!bot) return;

    logger.info(`[DiscordClientManager] Destroying bot ${discordAccountId}`);
    await bot.client.destroy();
    this.bots.delete(discordAccountId);
  }

  /* ------------------------------------------------------------
     HELPERS
  ------------------------------------------------------------ */
  public isBotReady(discordAccountId: string): boolean {
    return this.bots.has(discordAccountId);
  }

  public getClient(discordAccountId: string): Client | null {
    return this.bots.get(discordAccountId)?.client ?? null;
  }

  /* ------------------------------------------------------------
     PRELOAD STRUCTURES
  ------------------------------------------------------------ */

  private async preloadStructures(inst: DiscordBotRuntime) {
    logger.info("[DiscordClientManager] preload START");

    const c = inst.client;

    for (const [, guild] of c.guilds.cache) {
      inst.guilds.set(guild.id, guild.name);

      const channels = await guild.channels.fetch();

      for (const ch of channels.values()) {
        if (!ch) continue;

        if (isTextChannel(ch) || isForumChannel(ch)) {
          inst.channels.set(ch.id, ch);
        }

        if (isTextChannel(ch) || isForumChannel(ch)) {
          try {
            const active = await ch.threads.fetchActive();
            active.threads.forEach((t) => inst.threads.set(t.id, t));

            const archived = await ch.threads.fetchArchived();
            archived.threads.forEach((t) => inst.threads.set(t.id, t));
          } catch {}
        }
      }
    }

    logger.info(
      `[DiscordClientManager] preload DONE: guilds=${inst.guilds.size} channels=${inst.channels.size} threads=${inst.threads.size}`
    );
  }

  /* ------------------------------------------------------------
     EVENT HANDLERS FOR EACH BOT SEPARATELY
  ------------------------------------------------------------ */

  private registerEvents(discordAccountId: string, inst: DiscordBotRuntime) {
    const client = inst.client;

    client.on("ready", () => {
      logger.info(
        `[DiscordClientManager] Bot READY (${discordAccountId}) as ${client.user?.tag}`
      );
    });

    client.on("messageCreate", (msg) => {
      if (!msg.guild) return;

      emitDiscordNewMessage({
        accountId: discordAccountId,
        guildId: msg.guild.id,
        channelId: msg.channelId,
        message: msg,
      });
    });

    client.on("messageUpdate", (_, newMsg) => {
      const msg = newMsg as Message;
      if (!msg.guild) return;

      emitDiscordEditedMessage({
        accountId: discordAccountId,
        guildId: msg.guild.id,
        channelId: msg.channelId,
        message: msg,
      });
    });

    client.on("messageDelete", (msg) => {
      const m = msg as PartialMessage;
      if (!m.guild) return;

      emitDiscordDeletedMessage({
        accountId: discordAccountId,
        guildId: m.guild.id,
        channelId: m.channel!.id,
        messageId: m.id!,
      });
    });

    client.on("typingStart", (typing: Typing) => {
      emitDiscordTyping({
        accountId: discordAccountId,
        guildId: typing.guild?.id ?? "",
        channelId: typing.channel.id,
        userId: typing.user?.id ?? "",
        username: typing.user?.username ?? "",
        isTyping: true,
      });
    });
  }

  /* ------------------------------------------------------------
     DIALOG TREE — SPECIFIC BOT
  ------------------------------------------------------------ */

  public async getDialogsTree(discordAccountId: string) {
    const inst = this.bots.get(discordAccountId);
    if (!inst) throw new Error("Bot not attached for this account");

    const result: any[] = [];

    for (const [guildId, guildName] of inst.guilds.entries()) {
      const guildBlock = {
        guildId,
        guildName,
        accountId: discordAccountId,
        channels: [] as any[],
      };

      for (const ch of inst.channels.values()) {
        if (ch.guildId !== guildId) continue;

        const cb = {
          platform: "discord",
          accountId: discordAccountId,
          guildId,
          chatId: ch.id,
          name: ch.name,
          discordType: isForumChannel(ch) ? "forum" : "text",
          isThread: false,
          parentId: null,
          threads: [] as any[],
        };

        for (const t of inst.threads.values()) {
          if (t.parentId !== ch.id) continue;

          cb.threads.push({
            platform: "discord",
            accountId: discordAccountId,
            guildId,
            chatId: t.id,
            name: t.name,
            discordType: "thread",
            isThread: true,
            parentId: ch.id,
          });
        }

        guildBlock.channels.push(cb);
      }

      result.push(guildBlock);
    }

    return result;
  }

  /* ------------------------------------------------------------
     FETCH HISTORY FOR SPECIFIC BOT
  ------------------------------------------------------------ */

  public async fetchMessages(
    discordAccountId: string,
    channelId: string,
    limit = 50
  ) {
    const inst = this.bots.get(discordAccountId);
    if (!inst) throw new Error("Bot not attached for this account");

    const ch = await inst.client.channels.fetch(channelId);

    if (!ch || !("messages" in ch)) {
      throw new Error(`Channel has no messages: ${channelId}`);
    }

    const msgs = await (ch as TextBasedChannel).messages.fetch({ limit });
    return Array.from(msgs.values());
  }

  /* ------------------------------------------------------------
     SEND MESSAGE — SPECIFIC BOT
  ------------------------------------------------------------ */

  public async sendMessage(
    discordAccountId: string,
    channelId: string,
    text: string
  ) {
    const inst = this.bots.get(discordAccountId);
    if (!inst) throw new Error("Bot not attached for this account");

    const ch = await inst.client.channels.fetch(channelId);
    if (!isSendableChannel(ch)) throw new Error("Channel not sendable");

    return ch.send(text);
  }

  public async sendFile(
    discordAccountId: string,
    channelId: string,
    file: Buffer,
    name: string,
    caption?: string
  ) {
    const inst = this.bots.get(discordAccountId);
    if (!inst) throw new Error("Bot not attached for this account");

    const ch = await inst.client.channels.fetch(channelId);
    if (!isSendableChannel(ch)) throw new Error("Channel not sendable");

    return ch.send({
      content: caption ?? "",
      files: [{ attachment: file, name }],
    });
  }
}

export const discordClientManager = new DiscordClientManager();
