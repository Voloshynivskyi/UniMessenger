// services/telegram/telegramMessageIndexService.ts
import { prisma } from "../../lib/prisma";

export const TelegramMessageIndexService = {
  async addIndex(
    accountId: string,
    messageId: string,
    chatId: string,
    date?: Date
  ) {
    await prisma.telegramMessageIndex.upsert({
      where: {
        accountId_messageId: {
          accountId,
          messageId,
        },
      },
      update: {
        chatId,
        date: date ?? undefined,
      },
      create: {
        accountId,
        messageId,
        chatId,
        date: date ?? undefined,
      },
    });
  },

  async findChatByMessageId(accountId: string, messageId: string) {
    return prisma.telegramMessageIndex.findUnique({
      where: {
        accountId_messageId: {
          accountId,
          messageId,
        },
      },
    });
  },

  async markDeleted(accountId: string, messageId: string) {
    await prisma.telegramMessageIndex.updateMany({
      where: {
        accountId,
        messageId,
      },
      data: {
        deleted: true,
      },
    });
  },
};
