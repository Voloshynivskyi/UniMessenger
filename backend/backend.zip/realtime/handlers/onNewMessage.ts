// backend/realtime/handlers/onNewMessage.ts

import { Api } from "telegram";
import { logger } from "../../utils/logger";
import { handleTelegramMessageEvent } from "./handleTelegramMessageEvent";
import { telegramPeerToChatId } from "../../utils/telegramPeerToChatId";
import { appendLog } from "../../utils/debugLogger";

/**
 * Handles incoming new message events from Telegram (high-level NewMessage)
 *
 * - Resolves full chat (for channels we get accessHash)
 * - Falls back to peer-based chatId for private/group chats
 * - Delegates unified payload construction to handleTelegramMessageEvent
 */
export async function onNewMessage(
  event: any,
  accountId: string,
  userId: string
) {
  try {
    logger.info("=== [onNewMessage] EVENT FIRED ===");
    logger.info(`accountId=${accountId}, userId=${userId}`);

    // 🔥 DEBUG RAW EVENT
    appendLog("HL_NEW_EVENT_RAW", {
      accountId,
      userId,
      eventClass: event?.constructor?.name,
      messageClass: event?.message?.constructor?.name,
      rawEvent: event,
    });

    if (!event || !event.message) {
      logger.warn("[onNewMessage] No event.message");
      appendLog("HL_NEW_NO_MESSAGE", { event });
      return;
    }

    const msg = event.message as Api.Message;

    logger.info(`[onNewMessage] msg.className = ${msg.className}`);
    logger.info(`[onNewMessage] msg.id = ${msg.id}`);
    logger.info(`[onNewMessage] msg.date = ${msg.date}`);
    logger.info(`[onNewMessage] msg.out = ${msg.out}`);
    logger.info("[onNewMessage] msg keys:", Object.keys(msg));

    appendLog("HL_NEW_MSG_INFO", {
      msgId: msg.id,
      className: msg.className,
      date: msg.date,
      out: msg.out,
      peerId: msg.peerId,
      fromId: msg.fromId,
      message: msg.message,
    });

    // ----------------------------------------------------------
    // Resolve full chat for channels (get accessHash)
    // ----------------------------------------------------------
    let resolvedChat: any = null;
    let resolvedChatId: string | null = null;
    let resolvedAccessHash: string | null = null;

    try {
      resolvedChat = await msg.getChat();
      if (resolvedChat) {
        resolvedChatId = String(resolvedChat.id);
        resolvedAccessHash = resolvedChat.accessHash ?? null;

        appendLog("HL_NEW_CHAT_RESOLVED", {
          msgId: msg.id,
          chatId: resolvedChatId,
          accessHash: resolvedAccessHash,
          chatObject: resolvedChat,
        });
      }
    } catch (err) {
      logger.warn(
        "[onNewMessage] Failed to resolve chat via msg.getChat(), fallback to peerId...",
        { err }
      );

      appendLog("HL_NEW_CHAT_RESOLVE_FAIL", {
        msgId: msg.id,
        error: String(err),
      });
    }

    // Fallback to peer-based chatId for private/group dialogs
    if (!resolvedChatId && msg.peerId) {
      resolvedChatId = telegramPeerToChatId(msg.peerId);

      appendLog("HL_NEW_FALLBACK_PEER_ID", {
        msgId: msg.id,
        peerId: msg.peerId,
        resolvedChatId,
      });
    }

    logger.info(
      `[onNewMessage] Resolved chatId = ${
        resolvedChatId ?? "null"
      } | accessHash = ${resolvedAccessHash ?? "null"}`
    );

    appendLog("HL_NEW_FINAL_CHAT_RESOLUTION", {
      msgId: msg.id,
      chatId: resolvedChatId,
      accessHash: resolvedAccessHash,
    });

    // ----------------------------------------------------------
    // Delegate to unified pipeline
    // ----------------------------------------------------------
    await handleTelegramMessageEvent({
      kind: "NEW",
      msg,
      accountId,
      userId,
      resolvedChatId,
      resolvedAccessHash,
    });
  } catch (err) {
    logger.error("[onNewMessage] ERROR:", { err });

    appendLog("HL_NEW_FATAL_ERROR", {
      error: String(err),
      full: err,
    });
  }
}
