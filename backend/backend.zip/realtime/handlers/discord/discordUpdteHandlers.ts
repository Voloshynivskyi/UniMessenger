// backend/realtime/handlers/discord/discordUpdteHandlers.ts
import { getSocketGateway } from "../../socketGateway";
import { parseDiscordMessage } from "../../../utils/discord/parseDiscordMessage";
import { prisma } from "../../../lib/prisma";

export async function emitDiscordNewMessage(
  accountId: string,
  rawMessage: any
) {
  const account = await prisma.discordAccount.findUnique({
    where: { id: accountId },
  });

  if (!account) return;

  const payload = {
    platform: "discord",
    accountId,
    timestamp: new Date().toISOString(),
    message: parseDiscordMessage(rawMessage, accountId),
  };

  getSocketGateway().emitToUser(account.userId, "discord:new_message", payload);
}

export async function emitDiscordEditedMessage(
  accountId: string,
  rawMessage: any
) {
  const account = await prisma.discordAccount.findUnique({
    where: { id: accountId },
  });

  if (!account) return;

  const payload = {
    platform: "discord",
    accountId,
    timestamp: new Date().toISOString(),
    message: parseDiscordMessage(rawMessage, accountId),
  };

  getSocketGateway().emitToUser(
    account.userId,
    "discord:message_edited",
    payload
  );
}

export async function emitDiscordDeletedMessage(
  accountId: string,
  channelId: string,
  messageId: string
) {
  const account = await prisma.discordAccount.findUnique({
    where: { id: accountId },
  });

  if (!account) return;

  const payload = {
    platform: "discord",
    accountId,
    timestamp: new Date().toISOString(),
    chatId: channelId,
    messageIds: [messageId],
  };

  getSocketGateway().emitToUser(
    account.userId,
    "discord:message_deleted",
    payload
  );
}

export async function emitDiscordTyping(
  accountId: string,
  chatId: string,
  userId: string,
  username: string,
  isTyping: boolean
) {
  const account = await prisma.discordAccount.findUnique({
    where: { id: accountId },
  });

  if (!account) return;

  const payload = {
    platform: "discord",
    accountId,
    timestamp: new Date().toISOString(),
    chatId,
    userId,
    username,
    isTyping,
  };

  getSocketGateway().emitToUser(account.userId, "discord:typing", payload);
}
