// backend/realtime/handlers/discord/discordUpdateHandlers.ts
import { getSocketGateway } from "../../socketGateway";
import { parseDiscordMessage } from "../../../utils/discord/parseDiscordMessage";
import { prisma } from "../../../lib/prisma";
import { logger } from "../../../utils/logger";

/* ============================================================
   INTERNAL HELPERS
============================================================ */

async function resolveAccount(accountId: string) {
  const account = await prisma.discordAccount.findUnique({
    where: { id: accountId },
  });

  if (!account) {
    logger.warn(`[DiscordRealtime] Account not found: ${accountId}`);
    return null;
  }

  return account;
}

/* ============================================================
   NEW MESSAGE
============================================================ */

export async function emitDiscordNewMessage(p: {
  accountId: string;
  guildId: string;
  channelId: string;
  message: any;
}) {
  const { accountId, guildId, channelId, message } = p;

  const account = await resolveAccount(accountId);
  if (!account) return;

  const parsed = parseDiscordMessage({
    message,
    accountId,
    guildId,
    channelId,
  });

  logger.info(
    `[DiscordRealtime] NEW → user=${account.userId} guild=${guildId} channel=${channelId} msg=${parsed.messageId}`
  );

  getSocketGateway().emitToUser(account.userId, "discord:new_message", {
    platform: "discord",
    accountId,
    guildId,
    channelId,
    timestamp: new Date().toISOString(),
    message: parsed,
  });
}

/* ============================================================
   EDITED MESSAGE
============================================================ */

export async function emitDiscordEditedMessage(p: {
  accountId: string;
  guildId: string;
  channelId: string;
  message: any;
}) {
  const { accountId, guildId, channelId, message } = p;

  const account = await resolveAccount(accountId);
  if (!account) return;

  const parsed = parseDiscordMessage({
    message,
    accountId,
    guildId,
    channelId,
  });

  logger.info(
    `[DiscordRealtime] EDIT → user=${account.userId} guild=${guildId} channel=${channelId} msg=${parsed.messageId}`
  );

  getSocketGateway().emitToUser(account.userId, "discord:message_edited", {
    platform: "discord",
    accountId,
    guildId,
    channelId,
    timestamp: new Date().toISOString(),
    message: parsed,
  });
}

/* ============================================================
   DELETED MESSAGE
============================================================ */

export async function emitDiscordDeletedMessage(p: {
  accountId: string;
  guildId: string;
  channelId: string;
  messageId: string;
}) {
  const { accountId, guildId, channelId, messageId } = p;

  const account = await resolveAccount(accountId);
  if (!account) return;

  logger.info(
    `[DiscordRealtime] DELETE → user=${account.userId} guild=${guildId} channel=${channelId} msg=${messageId}`
  );

  getSocketGateway().emitToUser(account.userId, "discord:message_deleted", {
    platform: "discord",
    accountId,
    guildId,
    channelId,
    timestamp: new Date().toISOString(),
    messageIds: [messageId],
  });
}

/* ============================================================
   TYPING
============================================================ */

export async function emitDiscordTyping(p: {
  accountId: string;
  guildId: string;
  channelId: string;
  userId: string;
  username: string;
  isTyping: boolean;
}) {
  const { accountId, guildId, channelId, userId, username, isTyping } = p;

  const account = await resolveAccount(accountId);
  if (!account) return;

  logger.info(
    `[DiscordRealtime] TYPING → user=${account.userId} guild=${guildId} channel=${channelId} by=${username}`
  );

  getSocketGateway().emitToUser(account.userId, "discord:typing", {
    platform: "discord",
    accountId,
    guildId,
    channelId,
    userId,
    username,
    isTyping,
    timestamp: new Date().toISOString(),
  });
}
