// backend/realtime/handlers/onRawUpdate.ts

import { logger } from "../../utils/logger";
import {
  telegramUpdateHandlers,
  isTelegramUpdateType,
  type TelegramUpdateType,
} from "../telegramUpdateHandlers";

export async function onRawUpdate(
  update: any,
  accountId: string,
  userId: string
) {
  try {
    const raw = update?.update ?? update;
    const className =
      raw?.className ?? raw?.constructor?.name ?? "UNKNOWN_RAW_TYPE";

    logger.info("=== [onRawUpdate] RAW EVENT ===");
    logger.info(`accountId=${accountId}, userId=${userId}`);
    logger.info(`[onRawUpdate] raw class = ${className}`);
    logger.info("[onRawUpdate] keys:", Object.keys(raw || {}));

    if (!className || !isTelegramUpdateType(className)) {
      // це raw, який ми поки не обробляємо (можна просто ігнорити)
      return;
    }

    const handler = telegramUpdateHandlers[className as TelegramUpdateType];
    if (!handler) {
      logger.warn(`[onRawUpdate] No handler for ${className}`);
      return;
    }

    await handler({ update: raw, accountId, userId });
  } catch (err) {
    logger.error("[onRawUpdate] ERROR:", { err });
  }
}
