// backend/realtime/handlers/onEditedMessage.ts

import { Api } from "telegram";
import { logger } from "../../utils/logger";
import { handleTelegramMessageEvent } from "./handleTelegramMessageEvent";
import { telegramPeerToChatId } from "../../utils/telegramPeerToChatId";

/**
 * Handles edited message events from Telegram (high-level EditedMessage)
 *
 * Uses the same resolution pipeline and unified payload builder
 * as NEW messages to keep the format consistent.
 */
export async function onEditedMessage(
  event: any,
  accountId: string,
  userId: string
) {
  try {
    logger.info("=== [onEditedMessage] EDIT EVENT FIRED ===");

    if (!event || !event.message) {
      logger.warn("[onEditedMessage] No message in event");
      return;
    }

    const msg = event.message as Api.Message;

    // ----------------------------------------------
    // Resolve chatId (same as onNewMessage)
    // ----------------------------------------------
    let resolvedChat: any = null;
    let resolvedChatId: string | null = null;
    let resolvedAccessHash: string | null = null;

    try {
      resolvedChat = await msg.getChat();
      if (resolvedChat) {
        resolvedChatId = String(resolvedChat.id);
        resolvedAccessHash = resolvedChat.accessHash ?? null;
      }
    } catch (err) {
      logger.warn(
        "[onEditedMessage] msg.getChat() failed, fallback to peerId",
        { err }
      );
    }

    if (!resolvedChatId && msg.peerId) {
      resolvedChatId = telegramPeerToChatId(msg.peerId);
    }

    if (!resolvedChatId) {
      logger.error("[onEditedMessage] Could NOT resolve chatId!");
      return;
    }

    await handleTelegramMessageEvent({
      kind: "EDIT",
      msg,
      accountId,
      userId,
      resolvedChatId,
      resolvedAccessHash,
    });
  } catch (err) {
    logger.error("[onEditedMessage] ERROR:", { err });
  }
}
