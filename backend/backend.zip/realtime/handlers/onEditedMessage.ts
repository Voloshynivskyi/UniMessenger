// backend/realtime/handlers/onEditedMessage.ts

import { Api } from "telegram";
import { logger } from "../../utils/logger";
import { handleTelegramMessageEvent } from "./handleTelegramMessageEvent";

export async function onEditedMessage(
  event: any,
  accountId: string,
  userId: string
) {
  try {
    logger.info("=== [onEditedMessage] EVENT FIRED ===");
    logger.info(`accountId=${accountId}, userId=${userId}`);

    if (!event || !event.message) {
      logger.warn("[onEditedMessage] No event.message");
      return;
    }

    const msg = event.message as Api.Message;

    logger.info(`[onEditedMessage] msg.className = ${msg.className}`);
    logger.info(`[onEditedMessage] msg.id = ${msg.id}`);
    logger.info(`[onEditedMessage] msg.date = ${msg.date}`);
    logger.info(`[onEditedMessage] msg.out = ${msg.out}`);
    logger.info("[onEditedMessage] msg keys:", Object.keys(msg));

    await handleTelegramMessageEvent({
      kind: "EDIT",
      msg,
      accountId,
      userId,
    });
  } catch (err) {
    logger.error("[onEditedMessage] ERROR:", { err });
  }
}
