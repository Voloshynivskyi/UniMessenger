// backend/realtime/handlers/handleTelegramMessageEvent.ts

import { Api } from "telegram";
import { logger } from "../../utils/logger";
import { getSocketGateway } from "../../realtime/socketGateway";
import { TelegramMessageIndexService } from "../../services/telegram/telegramMessageIndexService";
import {
  extractMediaFromMessage,
  type TelegramRealtimeMedia,
  type TelegramRealtimeMessageType,
} from "../../utils/telegramMedia";

/**
 * Realtime message shape, який летить на фронт
 */
interface TelegramRealtimeMessage {
  id: string;
  text: string;
  date: string;
  from: {
    id: string;
    name: string;
  };
  isOutgoing: boolean;

  type: TelegramRealtimeMessageType;
  media?: TelegramRealtimeMedia | null;
  mediaGroupId?: string | null;
}

/**
 * Handles Telegram message events (new or edited messages)
 *
 * Цей хендлер:
 *  - будує realtime payload
 *  - викликає media-parser
 *  - індексує нові повідомлення
 *  - шле сокет-івенти
 */
export async function handleTelegramMessageEvent({
  kind,
  msg,
  accountId,
  userId,
  resolvedChatId,
  resolvedAccessHash,
}: {
  kind: "NEW" | "EDIT";
  msg: Api.Message;
  accountId: string;
  userId: string;
  resolvedChatId?: string | null;
  resolvedAccessHash?: string | null;
}) {
  try {
    logger.info("=== [handleTelegramMessageEvent] FIRED ===");
    if (!msg) return;

    const socket = getSocketGateway();

    // ------------------------------------------------------
    // 1) Chat ID (з резолвера)
    // ------------------------------------------------------
    const chatId = resolvedChatId ?? "unknown";

    // ------------------------------------------------------
    // 2) Sender
    // ------------------------------------------------------
    let senderUserId: string | null = null;

    if (msg.fromId instanceof Api.PeerUser) {
      senderUserId = String(msg.fromId.userId);
    } else if (msg.peerId instanceof Api.PeerUser) {
      senderUserId = String(msg.peerId.userId);
    }

    const from = {
      id: senderUserId ?? "0",
      name: `User ${senderUserId ?? "unknown"}`,
    };

    // ------------------------------------------------------
    // 3) Text (message / caption)
    // ------------------------------------------------------
    const text = msg.message ?? "";

    // ------------------------------------------------------
    // 4) Date → ISO
    // ------------------------------------------------------
    const dateIso = new Date(msg.date * 1000).toISOString();

    // ------------------------------------------------------
    // 5) Media parsing (photo, video, sticker, voice, etc.)
    // ------------------------------------------------------
    const mediaInfo = extractMediaFromMessage(msg);

    const realtimeMessage: TelegramRealtimeMessage = {
      id: String(msg.id),
      text,
      date: dateIso,
      from,
      isOutgoing: msg.out ?? false,
      type: mediaInfo.type,
      media: mediaInfo.media,
      mediaGroupId: mediaInfo.mediaGroupId,
    };

    // ------------------------------------------------------
    // 6) Index (NEW only)
    // ------------------------------------------------------
    if (kind === "NEW") {
      await TelegramMessageIndexService.addIndex(
        accountId,
        String(msg.id),
        chatId,
        new Date(msg.date * 1000),
        {
          rawPeerType: "dialog",
          rawPeerId: chatId,
          rawAccessHash: resolvedAccessHash ?? null,
        }
      );
    }

    // ------------------------------------------------------
    // 7) Payloads
    //    - NEW → telegram:new_message
    //    - EDIT → telegram:message_edited
    // ------------------------------------------------------
    const baseMeta = {
      platform: "telegram" as const,
      accountId,
      timestamp: new Date().toISOString(),
    };

    if (kind === "NEW") {
      const payload = {
        ...baseMeta,
        chatId,
        message: realtimeMessage,
      };

      logger.info(
        `[handleTelegramMessageEvent] Emitting telegram:new_message → chatId=${chatId}, msgId=${msg.id}`
      );
      socket.emitToUser(userId, "telegram:new_message", payload);
    } else {
      const payload = {
        ...baseMeta,
        chatId,
        messageId: String(msg.id),
        newText: text,
        from,
        // розширений unified-вигляд відредагованого повідомлення
        updated: realtimeMessage,
      };

      logger.info(
        `[handleTelegramMessageEvent] Emitting telegram:message_edited → chatId=${chatId}, msgId=${msg.id}`
      );
      socket.emitToUser(userId, "telegram:message_edited", payload);
    }

    logger.info("[handleTelegramMessageEvent] DONE");
  } catch (err) {
    logger.error("[handleTelegramMessageEvent] ERROR:", { err });
  }
}
