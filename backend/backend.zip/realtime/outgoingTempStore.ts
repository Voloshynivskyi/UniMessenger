// backend/realtime/outgoingTempStore.ts

export interface OutgoingTempRecord {
  tempId: string | number;
  chatId: string;
  createdAt: number;
}

class OutgoingTempStore {
  private queues = new Map<string, OutgoingTempRecord[]>();

  private key(accountId: string, chatId: string): string {
    return `${accountId}:${chatId}`;
  }

  push(accountId: string, chatId: string, record: OutgoingTempRecord) {
    const k = this.key(accountId, chatId);
    const queue = this.queues.get(k) ?? [];
    queue.push(record);
    this.queues.set(k, queue);
  }

  shift(accountId: string, chatId: string): OutgoingTempRecord | null {
    const k = this.key(accountId, chatId);
    const queue = this.queues.get(k);
    if (!queue || queue.length === 0) return null;
    const record = queue.shift()!;
    this.queues.set(k, queue);
    return record;
  }

  peek(accountId: string, chatId: string): OutgoingTempRecord | null {
    const k = this.key(accountId, chatId);
    const queue = this.queues.get(k);
    return queue?.[0] ?? null;
  }

  remove(accountId: string, chatId: string, tempId: string | number): void {
    const k = this.key(accountId, chatId);
    const queue = this.queues.get(k);
    if (!queue) return;

    const filtered = queue.filter((r) => r.tempId !== tempId);
    this.queues.set(k, filtered);
  }

  list(accountId: string, chatId: string): OutgoingTempRecord[] {
    const k = this.key(accountId, chatId);
    return this.queues.get(k) ?? [];
  }
}

export const outgoingTempStore = new OutgoingTempStore();
