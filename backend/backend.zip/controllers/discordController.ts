// backend/controllers/discordController.ts
import type { Request, Response } from "express";
import { discordService } from "../services/discord/discordService";
import { logger } from "../utils/logger";

/* ============================================================
   Helpers
============================================================ */
function ok(res: Response, data: any) {
  return res.status(200).json({ status: "ok", data });
}

function err(res: Response, message: string, code = "ERROR", http = 400) {
  return res.status(http).json({ status: "error", message, code });
}

/* ============================================================
   OAUTH
============================================================ */

export async function discordGetOAuthUrl(req: Request, res: Response) {
  try {
    const userId = req.userId!;
    const { url } = discordService.getOAuthUrl(userId);
    return ok(res, { url });
  } catch (e: any) {
    logger.error("discordGetOAuthUrl failed", { e });
    return err(res, e.message);
  }
}

export async function discordOAuthCallback(req: Request, res: Response) {
  try {
    const { code, state } = req.query as any;
    if (!code || !state) return err(res, "Missing code/state");

    const { account } = await discordService.handleOAuthCallback(code, state);

    const html = `
      <html>
        <body>
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: "DISCORD_OAUTH_SUCCESS" }, "*");
            }
            window.close();
          </script>
          OAuth done. You may close this window.
        </body>
      </html>
    `;

    res.status(200).send(html);
  } catch (e: any) {
    logger.error("discordOAuthCallback failed", { e });
    return res.status(500).send("OAuth failed");
  }
}

export async function discordGetOAuthAccount(req: Request, res: Response) {
  try {
    const userId = req.userId!;
    const account = await discordService.getCurrentOAuthAccount(userId);
    return ok(res, { account });
  } catch (e: any) {
    return err(res, e.message);
  }
}

export async function discordGetOAuthGuilds(req: Request, res: Response) {
  try {
    const { accountId } = req.query as any;
    if (!accountId) return err(res, "accountId is required");

    const guilds = await discordService.getOAuthGuilds(accountId);
    return ok(res, { guilds });
  } catch (e: any) {
    return err(res, e.message);
  }
}

/* ============================================================
   BOT — ONE GLOBAL BOT
============================================================ */

export async function discordGetDialogs(req: Request, res: Response) {
  try {
    const userId = req.userId!;
    const dialogs = await discordService.getDialogsForUser(userId);
    return ok(res, { dialogs });
  } catch (e: any) {
    return err(res, e.message);
  }
}

export async function discordGetHistory(req: Request, res: Response) {
  try {
    const { chatId } = req.query as any;
    if (!chatId) return err(res, "chatId required");

    const messages = await discordService.getHistory(chatId);
    return ok(res, { messages });
  } catch (e: any) {
    return err(res, e.message);
  }
}

export async function discordSendMessage(req: Request, res: Response) {
  try {
    const userId = req.userId!;
    const { chatId, text } = req.body;

    if (!chatId || !text) return err(res, "chatId + text required");

    const msg = await discordService.sendMessage(chatId, text, userId);
    return ok(res, { message: msg });
  } catch (e: any) {
    return err(res, e.message);
  }
}

export async function discordSendFile(req: Request, res: Response) {
  try {
    const userId = req.userId!;
    const { chatId, caption } = req.body;
    const file = req.file;

    if (!chatId || !file) return err(res, "chatId + file required");

    const msg = await discordService.sendFile(
      chatId,
      file.buffer,
      file.originalname,
      caption,
      userId
    );

    return ok(res, { message: msg });
  } catch (e: any) {
    return err(res, e.message);
  }
}
export async function discordLinkGuild(req: Request, res: Response) {
  try {
    const userId = req.userId!;
    const { discordAccountId, guildId } = req.body;

    if (!discordAccountId || !guildId)
      return err(res, "discordAccountId + guildId required");

    const result = await discordService.linkGuild(
      discordAccountId,
      guildId,
      userId
    );
    return ok(res, result);
  } catch (e: any) {
    return err(res, e.message);
  }
}
