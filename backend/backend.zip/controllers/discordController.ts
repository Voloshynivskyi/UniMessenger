// backend/controllers/discordController.ts
import type { Request, Response } from "express";
import { discordService } from "../services/discord/discordService";

interface ApiSuccessResponse<T = unknown> {
  status: "ok";
  data: T;
}

interface ApiErrorResponse {
  status: "error";
  message: string;
  code?: string;
}

function sendOk<T>(res: Response, data: T, http = 200) {
  const body: ApiSuccessResponse<T> = { status: "ok", data };
  return res.status(http).json(body);
}

function sendError(
  res: Response,
  message: string,
  code = "UNEXPECTED",
  http = 500
) {
  const body: ApiErrorResponse = { status: "error", message, code };
  return res.status(http).json(body);
}

/* ---------------------------------------------
 * POST /discord/addAccount
 * --------------------------------------------- */
export async function discordAddAccount(req: Request, res: Response) {
  try {
    const userId = req.userId!; // ✅ як у Telegram
    const { botToken } = req.body;

    if (!botToken) {
      return sendError(res, "botToken is required", "BAD_REQUEST", 400);
    }

    const account = await discordService.addAccount(userId, botToken);
    return sendOk(res, { account });
  } catch (err: any) {
    return sendError(res, err.message);
  }
}

/* ---------------------------------------------
 * POST /discord/removeAccount
 * --------------------------------------------- */
export async function discordRemoveAccount(req: Request, res: Response) {
  try {
    const { accountId } = req.body;

    if (!accountId) {
      return sendError(res, "accountId is required", "BAD_REQUEST", 400);
    }

    const result = await discordService.removeAccount(accountId);
    return sendOk(res, result);
  } catch (err: any) {
    return sendError(res, err.message);
  }
}

/* ---------------------------------------------
 * GET /discord/accounts
 * --------------------------------------------- */
export async function discordGetAccounts(req: Request, res: Response) {
  try {
    const userId = req.userId!; // ✅ як у Telegram
    const accounts = await discordService.getAccounts(userId);
    return sendOk(res, { accounts });
  } catch (err: any) {
    return sendError(res, err.message);
  }
}

/* ---------------------------------------------
 * GET /discord/dialogs
 * --------------------------------------------- */
export async function discordGetDialogs(req: Request, res: Response) {
  try {
    const { accountId } = req.query as { accountId: string };

    if (!accountId) {
      return sendError(res, "accountId is required", "BAD_REQUEST", 400);
    }

    const dialogs = await discordService.getDialogs(accountId);
    return sendOk(res, { dialogs });
  } catch (err: any) {
    return sendError(res, err.message);
  }
}

/* ---------------------------------------------
 * GET /discord/history
 * --------------------------------------------- */
export async function discordGetHistory(req: Request, res: Response) {
  try {
    const { accountId, channelId, limit } = req.query as any;

    if (!accountId || !channelId) {
      return sendError(
        res,
        "accountId and channelId are required",
        "BAD_REQUEST",
        400
      );
    }

    const messages = await discordService.getHistory(
      accountId,
      channelId,
      limit ? Number(limit) : 50
    );

    return sendOk(res, { messages });
  } catch (err: any) {
    return sendError(res, err.message);
  }
}

/* ---------------------------------------------
 * POST /discord/sendMessage
 * --------------------------------------------- */
export async function discordSendMessage(req: Request, res: Response) {
  try {
    const { accountId, channelId, text } = req.body;

    if (!accountId || !channelId || !text) {
      return sendError(
        res,
        "accountId, channelId and text are required",
        "BAD_REQUEST",
        400
      );
    }

    const message = await discordService.sendMessage(
      accountId,
      channelId,
      text
    );

    return sendOk(res, { message });
  } catch (err: any) {
    return sendError(res, err.message);
  }
}

/* ---------------------------------------------
 * POST /discord/sendFile
 * --------------------------------------------- */
export async function discordSendFile(req: Request, res: Response) {
  try {
    const { accountId, channelId, caption } = req.body;
    const file = req.file;

    if (!accountId || !channelId || !file) {
      return sendError(
        res,
        "accountId, channelId and file are required",
        "BAD_REQUEST",
        400
      );
    }

    const message = await discordService.sendFile(
      accountId,
      channelId,
      file.buffer,
      file.originalname,
      caption
    );

    return sendOk(res, { message });
  } catch (err: any) {
    return sendError(res, err.message);
  }
}
